const { expect } = require("chai");

class LoginPage {

    async navigate() {
        await page.goto('https://demoqa.com/login');
        setTimeout(3000);
    }
    async login(username, password) {
        await page.click('//input[@id="userName"]',username);
        await page.fill('//input[@id="userName"]',username);        
        await page.fill('//input[@id="password"]',password);
        await page.click('//button[@id="login"]');
    }
  }
  module.exports = { LoginPage };