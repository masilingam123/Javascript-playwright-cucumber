const {Given, When, Then} = require ('cucumber')
const {LoginPage} = require('../../page_object/login.page')


const loginpage = new LoginPage();


Given('User launched demoqa login page', async()=>{
    await loginpage.navigate();
 });

When('User logged in eshop using the valid emailid {string} and the valid password {string}', async (email, password) =>{
    await loginpage.login(email,password); 
});

Then('user should see a shop home page',async()=>{
    
});
